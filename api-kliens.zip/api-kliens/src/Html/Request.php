<?php

namespace App\Html;

use App\RestApiClient\Client;
use App\Interfaces\PageInterface;
use App\Html\AbstractPage;
//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;
class Request {

    static function handle()
    {
        switch ($_SERVER["REQUEST_METHOD"]){
            case "POST":
                self::postRequest();
                break;

        }
    }
/**
 * @api {post} /request Post Request Handler
 * @apiName PostRequestHandler
 * @apiGroup Request
 *
 * @apiDescription A funkció kezeli az összes POST kérés esetén végrehajtandó műveletet. Az adott gomb típusának megfelelően más-más alfunkciót hív meg.
 *
 * @apiParam {String} [btn-home] Kezdőlapra navigálás.
 * @apiParam {String} [btn-counties] Megyék megjelenítése.
 * @apiParam {String} [btn-save-counties] Új megye hozzáadása.
 * @apiParam {String} [btn-del-county] Megy törlés.
 * @apiParam {String} [btn-save-new-county] Megye módosítás mentése.
 * @apiParam {String} [btn-cearch] Megye keresés.
 * @apiParam {String} [btn-edit-city] Város módosító részt felhozó gomb .
 * @apiParam {String} [btn-save-edit-county] Város változtatás mentésének hitelesító gombja.
 * @apiParam {String} [btn-show-cities] A városok megjelenítése.
 * @apiParam {String} [btn-save-new-city] Új város hozzáadása.
 * @apiParam {String} [btn-filter-letter] A városok kezdőbetűjének lekérése és gombá alakítása.
 * @apiParam {String} [btn-del-city] A város törlésének gombja.
 * @apiParam {String} [btn-search-city] A keresés a megadott paraméterek alapján elvégzi.
 * @apiParam {String} [btn-edit-city] A módosítás webolal részt megnyitja.
 * @apiParam {String} [btn-save-edit-city] A módosítás a megadott paraméterek alapján elvégzi.
 * 
 * @apiSuccess {String} status Visszaadja a kérelem végrehajtásának állapotát.
 *
 * @apiError {String} error Hiba esetén visszaadott információ.
 */
    private static function postRequest()
    {
        $request = $_REQUEST;

        switch ($request) {
            case isset($request['btn-home']):
                break;

            case isset($request['btn-counties']):
                PageCounties::table(self::getCounties());
                break;

            case isset($request['btn-save-county']):
                $client = new Client();
                if (!empty($request['id'])) {
                    $data['id'] = $request['id'];
                }
                break;

            case isset($request['btn-del-county']):
                $id = $request['btn-del-county'];
                $client = new Client();
                $response = $client->delete('counties/' . $id, $id);
                if ($response && isset($response['success']) && $response['success']) {
                    echo "Sikeres törlés!";
                } 
                PageCounties::table(self::getCounties());
                break;
            case isset($request['btn-save-new-county']):
                $name = $request['new_name'];
                $client = new Client();
                $response = $client->post('counties', ['name' => $name]);
                if ($response && isset($response['success']) && $response['success']) {
                    header("Location: " . $_SERVER['REQUEST_URI']);
                    exit; 
                } else {
                    echo "Hiba történt a mentés során!";
                }
                PageCounties::table(self::getCounties());
                break;
            case isset($request['btn-search']):
                $keyword = $_POST['keyword'];
                $results = self::searchCountiesByName($keyword);
                echo "<h2>Keresési eredmények:</h2>";
                AbstractPage::searchbar(); 
                AbstractPage::displaySearchResults($results, $keyword);
                break;
               
            case isset($request['btn-edit-county']):
                $id = $request['btn-edit-county'];
                $client = new Client();
                $county = $client->get('counties/' . $id); 

                PageCounties::displayEditForm($county); 
                break;
            case isset($request['btn-save-edit-county']):
                $id = $request['id'];
                $newName = $request['edit_name'];
                $client = new Client();
                        
                $response = $client->put('counties/' . $id, ['name' => $newName]);
                if ($response && isset($response['success']) && $response['success']) {
                    echo "A név sikeresen módosítva lett!";
                } else {
                    echo "Hiba történt a módosítás során!";
                }
                PageCounties::table(self::getCounties());
                break;

//cities part of the code:
            case isset($request['btn-show-cities']):
                self::handleShowCities($request);
                break;
                
            case isset($request['btn-filter-letter']):
                self::handleFilterLetter($request);
                break;
            case isset($request['btn-save-new-city']):
                self::handleNewCityRequest($request);
                break;

            case isset($request['btn-del-city']):
                self::handleCityDeletion($request);
                break;

            case isset($request['btn-search-city']):
                self::handleCitySearch($request['keyword']);
                break;
             case isset($request['btn-edit-city']):
                self::handleEditCity($request);
                break;
                
            case isset($request['btn-save-edit-city']):
                self::handleSaveEditCity($request);
                break;
            default:
                 $counties = self::getCounties();
                  PageCities::render($counties);
                break;
        }
    }
/**
 * @api {get} /counties Megyék lekérdezése
 * @apiName GetCounties
 * @apiGroup County
 *
 * @apiDescription Lekéri az összes megye adatait a REST API-tól.
 *
 * @apiSuccess {Object[]} counties Az összes megye adatai.
 * @apiSuccess {Number} counties.id Megye azonosítója.
 * @apiSuccess {String} counties.name Megye neve.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */
    private static function getCounties(): array
    {
        $client = new Client();
        $response = $client->get('counties');

        return $response['data'];
    }
/**
 * @api {get} /counties/search Megye keresése név alapján
 * @apiName SearchCountiesByName
 * @apiGroup County
 *
 * @apiDescription Megyék keresése név alapján.
 *
 * @apiParam {String} keyword A keresett megye neve.
 *
 * @apiSuccess {Object[]} counties A keresésnek megfelelő megye adatok.
 * @apiSuccess {Number} counties.id Megye azonosítója.
 * @apiSuccess {String} counties.name Megye neve.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    static function searchCountiesByName($keyword)
    {
        $client = new Client();
        $counties = $client->get('counties');
        
        $results = [];
        foreach ($counties['data'] as $county) {
            if (stripos($county['name'], $keyword) !== false) {
                $results[] = $county;
            }
        }
        
        return $results;
    }
/**
 * @api {get} /cities Városok lekérdezése
 * @apiName GetCities
 * @apiGroup City
 *
 * @apiDescription Lekéri az összes város adatait a REST API-tól.
 *
 * @apiSuccess {Object[]} cities Az összes város adatai.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Város irányítószáma.
 * @apiSuccess {Number} cities.id_county Megye azonosítója.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    private static function getCities(): array
    {
        $client = new Client();
        $response = $client->get('cities');

        return $response['data'] ?? [];
    }
/**
 * @api {get} /cities Megye alapján szűrt városok
 * @apiName FilterCitiesByCounty
 * @apiGroup City
 *
 * @apiDescription Megadott megyéhez tartozó városok listázása.
 *
 * @apiParam {Number} county_id A megye azonosítója.
 *
 * @apiSuccess {Object[]} cities Az adott megyéhez tartozó városok adatai.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    public static function filterCitiesByCounty(array $cities, ?int $countyId): array
    {
        if ($countyId === null) {
            return [];
        }

        return array_filter($cities, function ($city) use ($countyId) {
            return intval($city['id_county']) === $countyId;
        });
    }
/**
 * @api {get} /cities/filter Városok szűrése megyén és kezdőbetű alapján
 * @apiName FilterCitiesByCountyAndLetter
 * @apiGroup City
 *
 * @apiDescription Egy adott megyében található városok szűrése kezdőbetű alapján.
 *
 * @apiParam {Number} county_id A megye azonosítója.
 * @apiParam {String} letter Az első betű, amely alapján szűrjük a városokat.
 *
 * @apiSuccess {Object[]} cities A szűrésnek megfelelő városok.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    public static function filterCitiesByCountyAndLetter(array $cities, ?int $countyId, ?string $letter): array
    {
        if ($countyId === null) {
            return [];
        }

        $filteredCities = array_filter($cities, function ($city) use ($countyId) {
            return intval($city['id_county']) === $countyId;
        });

        if ($letter) {
            $filteredCities = array_filter($filteredCities, function ($city) use ($letter) {
                return stripos($city['city'], $letter) === 0;
            });
        }

        return $filteredCities;
    }
/**
 * @api {post} /request POST kérés kezelése
 * @apiName HandlePostRequest
 * @apiGroup Request
 *
 * @apiDescription A POST kérések feldolgozása, mint új város hozzáadása, város törlése stb.
 *
 * @apiSuccess {String} status A kérés sikeressége vagy hibája.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    public static function handlePostRequest()
    {
        if (isset($_POST['btn-save-new-city'])) {
            $selectedCountyId = $_POST['selected-county'] ?? null;
            $newCityName = $_POST['new_city-name'] ?? '';
            $newZipCode = $_POST['new_zip-code'] ?? '';
            if ($selectedCountyId && !empty($newCityName) && !empty($newZipCode)) {
                $client = new Client();
                $response = $client->post('cities', [
                    'name' => $newCityName,
                    'zip_code' => $newZipCode,
                    'county_id' => $selectedCountyId
                ]);

                if ($response && isset($response['success']) && $response['success']) {
                    echo "A város sikeresen hozzáadva!";
                }
            } else {
                echo "Kérlek válassz megyét és adj meg városnevet és irányítószámot!";
            }
        }
    }
/**
 * @api {post} /cities/add Új város hozzáadásának kezelése
 * @apiName HandleNewCityRequest
 * @apiGroup City
 *
 * @apiDescription Kezeli az új város hozzáadására irányuló kéréseket, ellenőrzi a bemeneti adatokat, és meghívja az API-t az új város mentéséhez. Ezt követően megjeleníti az aktuális városok listáját.
 *
 * @apiParam {String} new_city-name Az új város neve.
 * @apiParam {String} new_zip-code Az új város irányítószáma.
 * @apiParam {Number} selected-county A megye azonosítója, amelyhez az új város tartozik.
 *
 * @apiSuccess {String} message Sikeres mentés üzenete.
 * @apiSuccess {Object[]} cities Az összes város adatai a mentés után.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 * @apiSuccess {Number} cities.id_county A város megyéjének azonosítója.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */
    private static function handleNewCityRequest($request)
    {
        $newCityName = $request['new_city-name'] ?? null;
        $newZipCode = $request['new_zip-code'] ?? null;
        $selectedCountyId = $request['selected-county'] ?? null;

        if ($newCityName && $newZipCode && $selectedCountyId) {
            $response = self::addCity($newCityName, $newZipCode, $selectedCountyId);

            if ($response && isset($response['success']) && $response['success']) {
                echo "Új város hozzáadva!";
            } 
        } else {
            echo "Kérem, töltse ki az összes mezőt!";
        }
        $counties = self::getCounties();
        $cities = self::getCities();
        PageCities::render($counties, $cities, $selectedCountyId);
    }
/**
 * @api {post} /cities Új város hozzáadása
 * @apiName AddCity
 * @apiGroup City
 *
 * @apiDescription Egy új város hozzáadása a REST API-n keresztül.
 *
 * @apiParam {String} city A város neve.
 * @apiParam {String} zip_code Az irányítószám.
 * @apiParam {Number} id_county A megye azonosítója, amelyhez a város tartozik.
 *
 * @apiSuccess {String} message A sikeres mentés üzenete.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */
    private static function addCity($newCityName, $newZipCode, $selectedCountyId)
    {
        $client = new Client();
        return $client->post('cities', [
            'id_county' => $selectedCountyId,
            'city' => $newCityName,
            'zip_code' => $newZipCode
        ]);
    }
/**
 * @api {delete} /cities/:id Város törlése
 * @apiName HandleCityDeletion
 * @apiGroup City
 *
 * @apiDescription Egy város törlése a REST API-ból.
 *
 * @apiParam {Number} id A törölni kívánt város azonosítója.
 *
 * @apiSuccess {String} message A sikeres törlés üzenete.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */
    private static function handleCityDeletion($request)
    {
        $id = $request['btn-del-city'];
        $client = new Client();
        $response = $client->delete('cities/' . $id, $id);
    
        if ($response && isset($response['success']) && $response['success']) {
            echo "A város sikeresen törölve!";
        }
    
        $counties = self::getCounties();
        $cities = self::getCities();
        $selectedCountyId = $_POST['selected-county'] ?? null;
        PageCities::render($counties, $cities, $selectedCountyId);
    }
/**
 * @api {post} /cities/search Város keresése
 * @apiName HandleCitySearch
 * @apiGroup City
 *
 * @apiDescription Keresés város alapján, kilistázva a város adatait és a hozzá tartozó megye nevét.
 *
 * @apiParam {String} keyword A keresett város neve vagy irányítószáma.
 *
 * @apiSuccess {Object[]} cities Az összes találat a keresési feltételek alapján.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 * @apiSuccess {String} cities.county_name Megye neve.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    private static function handleCitySearch($keyword)
    {
        $client = new Client();
        $cities = $client->get('cities'); 
        $counties = $client->get('counties'); 
    
        $filteredCities = array_filter($cities['data'], function ($city) use ($keyword) {
            return stripos($city['city'], $keyword) !== false;
        });
    
        AbstractPage::displayCitySearchResults($filteredCities, $counties['data']);
    }
/**
 * @api {put} /cities/:id Városadatok módosításának mentése
 * @apiName HandleSaveEditCity
 * @apiGroup City
 *
 * @apiDescription Kezeli a meglévő város adatainak (név, irányítószám, megye) frissítését az API-n keresztül.
 *
 * @apiParam {Number} city_id A módosítandó város azonosítója.
 * @apiParam {String} city_name A frissített városnév.
 * @apiParam {String} zip_code Az új irányítószám.
 * @apiParam {Number} county_id A városhoz tartozó megye azonosítója.
 *
 * @apiSuccess {String} message A sikeres módosítás üzenete.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    private static function handleSaveEditCity($request)
    {
        $cityId = $request['city_id'];
        $updatedName = $request['city_name'];
        $updatedZipCode = $request['zip_code'];
        $updatedCountyId = $request['county_id'];

        $client = new Client();
        $response = $client->put("cities/$cityId", [
            'city' => $updatedName,
            'zip_code' => $updatedZipCode,
            'id_county' => $updatedCountyId
        ]);

        if ($response && isset($response['success']) && $response['success']) {
            echo "A város adatai sikeresen módosítva lettek!";
        }
        $counties = self::getCounties();
        $cities = self::getCities();
        PageCities::render($counties, $cities, $updatedCountyId);
    }
/**
 * @api {post} /cities/edit Város adatainak módosítása
 * @apiName HandleEditCity
 * @apiGroup City
 *
 * @apiDescription Egy adott város nevének, irányítószámának, vagy megyéjének módosítása.
 *
 * @apiParam {Number} city_id A módosítandó város azonosítója.
 * @apiParam {String} city_name A módosított város neve.
 * @apiParam {String} zip_code Az új irányítószám.
 * @apiParam {Number} county_id Az új megye azonosítója.
 *
 * @apiSuccess {String} message Sikeres módosítás üzenet.
 * @apiSuccess {Object} city A módosított város adatai.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */
    private static function handleEditCity($request)
    {
        $cityId = $request['btn-edit-city'];
        $client = new Client();

        $city = $client->get("cities/$cityId");
        $counties = self::getCounties();

        if ($city && isset($city['data'])) {
            PageCities::displayEditForm($city['data'], $counties); 
        } 
    }
/**
 * @api {post} /cities Városok megjelenítése
 * @apiName HandleShowCities
 * @apiGroup City
 *
 * @apiDescription Megjeleníti az összes várost, vagy egy adott megyéhez tartozó városokat.
 *
 * @apiParam {Number} [selected_county] A megye azonosítója, ha szűrni szeretnénk a városokat.
 *
 * @apiSuccess {Object[]} cities Az összes város adatai.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 * @apiSuccess {Number} cities.id_county Megye azonosítója.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    private static function handleShowCities($request)
    {
        $selectedCountyId = !empty($request['selected-county']) ? intval($request['selected-county']) : null;
    
        $counties = self::getCounties();
        $cities = self::getCities();
    
        PageCities::render($counties, $cities, $selectedCountyId);
    }
/**
 * @api {post} /cities/filter Városok szűrése kezdőbetű alapján
 * @apiName HandleFilterLetter
 * @apiGroup City
 *
 * @apiDescription Egy adott megyében található városok szűrése az első betűjük alapján.
 *
 * @apiParam {Number} selected_county Megye azonosítója.
 * @apiParam {String} filter_letter Az első betű, amely alapján a városokat szűrjük.
 *
 * @apiSuccess {Object[]} cities Az összes szűrt város adatai.
 * @apiSuccess {Number} cities.id Város azonosítója.
 * @apiSuccess {String} cities.city Város neve.
 * @apiSuccess {String} cities.zip_code Irányítószám.
 *
 * @apiError {String} error Hiba esetén visszaadott üzenet.
 */

    private static function handleFilterLetter($request)
    {
        $selectedCountyId = !empty($request['selected-county']) ? intval($request['selected-county']) : null;
        $filterLetter = !empty($request['filter-letter']) ? strtoupper($request['filter-letter']) : null;

        $counties = self::getCounties();
        $cities = self::getCities();

        PageCities::render($counties, $cities, $selectedCountyId, $filterLetter);
    }
}